import os
import numpy as np
import openmc
import openmc.stats
import nuscale.surfaces
import nuscale.materials
from nuscale.core import core_geometry
from nuscale.surfaces import surfs

# Remove previous .xml files if they exist
for f in os.listdir('.'):
    if f.endswith('.xml'):
        os.remove(os.path.join('.', f))

pitch = nuscale.surfaces.pin_cell_pitch
assembly_pitch = nuscale.surfaces.assembly_pitch
bottom_fuel = surfs['fuel bottom'].z0
top_fuel = surfs['fuel top'].z0

geometry = core_geometry(control_rods='SH4')

# Construct uniform initial source distribution over fissionable zones
lower_left = geometry.bounding_box[0]
upper_right = geometry.bounding_box[1]
source = openmc.source.Source(space=openmc.stats.Box(lower_left, upper_right))
source.space.only_fissionable = True
os.makedirs('./SH4', exist_ok=True)
settings = openmc.Settings()
settings.batches = 2700
settings.inactive = 200
settings.particles = 1000000
settings.output = {'tallies': False,
                   'path': 'SH4'}
settings.source = source
settings.sourcepoint = {'write': False}
settings.temperature = {
    'default': 900,
    'method': 'interpolation',
    'range': (300.0, 1500.0),
}

materials = openmc.Materials(nuscale.materials.mats.values())

model = openmc.Model()
model.settings = settings
model.geometry = geometry
model.materials = materials

model.run(threads=40)