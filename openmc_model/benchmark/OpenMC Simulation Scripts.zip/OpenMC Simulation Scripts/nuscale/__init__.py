coolant_temperature = 600.
struct_temperature = 600.
fuel_temperature = 900.